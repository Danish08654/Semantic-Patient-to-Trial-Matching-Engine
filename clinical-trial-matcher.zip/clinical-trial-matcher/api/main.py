import json
import numpy as np
import pandas as pd
import faiss
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from sentence_transformers import SentenceTransformer
from schema import PatientProfile, MatchResponse, TrialMatch, EligibilityCheck

app = FastAPI(
    title="Clinical Trial Match Engine",
    description="Semantic patient-to-trial matching using BioBERT and FAISS",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"]
)

# Load at startup
print("Loading BioBERT embedder...")
embedder = SentenceTransformer(
    "pritamdeka/BioBERT-mnli-snli-scinli-scitail-mednli-stsb"
)

print("Loading FAISS index...")
index = faiss.read_index("trial_faiss.index")

with open("trials_db.json") as f:
    trials_data = json.load(f)
trials_df = pd.DataFrame(trials_data)

with open("matcher_metadata.json") as f:
    metadata = json.load(f)

print(f"Ready. {index.ntotal} trials indexed.")


def build_patient_text(patient: dict) -> str:
    conditions  = ", ".join(patient.get('conditions', []))
    medications = ", ".join(patient.get('current_medications', []))

    biomarkers = []
    if patient.get('egfr_mutation'):   biomarkers.append("EGFR mutation positive")
    if patient.get('brca_mutation'):   biomarkers.append("BRCA mutation positive")
    if patient.get('pdl1_positive'):   biomarkers.append("PD-L1 positive")
    if patient.get('amyloid_positive'):biomarkers.append("amyloid positive")
    biomarker_text = ", ".join(biomarkers) if biomarkers else "no specific biomarkers"

    return f"""
    Patient profile: {patient.get('gender','Unknown')} aged {patient.get('age')} years.
    Diagnosed conditions: {conditions}.
    Current medications: {medications}.
    ECOG performance status: {patient.get('ecog_status')}.
    BMI: {patient.get('bmi')} kg/m2.
    eGFR: {patient.get('egfr_value')} mL/min.
    Biomarkers: {biomarker_text}.
    Prior therapies: {patient.get('prior_therapies', 0)}.
    Pregnant: {patient.get('is_pregnant', False)}.
    HbA1c: {patient.get('hba1c') or 'not applicable'}.
    MMSE score: {patient.get('mmse_score') or 'not applicable'}.
    """.strip()


def check_hard_eligibility(patient: dict, trial: dict):
    checks   = []
    eligible = True

    age_ok = trial['age_min'] <= patient['age'] <= trial['age_max']
    checks.append(EligibilityCheck(
        criterion='Age',
        status='PASS' if age_ok else 'FAIL',
        detail=f"Patient age {patient['age']} — Trial requires {trial['age_min']}-{trial['age_max']}"
    ))
    if not age_ok: eligible = False

    if patient.get('is_pregnant'):
        checks.append(EligibilityCheck(
            criterion='Pregnancy',
            status='FAIL',
            detail='Patient is pregnant — excluded from most trials'
        ))
        eligible = False
    else:
        checks.append(EligibilityCheck(
            criterion='Pregnancy',
            status='PASS',
            detail='Not pregnant'
        ))

    ecog_ok = patient.get('ecog_status', 0) <= 2
    checks.append(EligibilityCheck(
        criterion='ECOG Performance Status',
        status='PASS' if ecog_ok else 'FAIL',
        detail=f"Patient ECOG {patient.get('ecog_status')} — Requires 0-2"
    ))
    if not ecog_ok: eligible = False

    egfr_ok = patient.get('egfr_value', 0) >= 30
    checks.append(EligibilityCheck(
        criterion='Renal Function',
        status='PASS' if egfr_ok else 'WARN',
        detail=f"eGFR {patient.get('egfr_value')} mL/min — Threshold usually 30+"
    ))

    patient_conds = [c.lower() for c in patient.get('conditions', [])]
    trial_conds   = [c.lower() for c in trial.get('conditions', [])]
    cond_match    = any(
        any(tc in pc or pc in tc for pc in patient_conds)
        for tc in trial_conds
    )
    checks.append(EligibilityCheck(
        criterion='Condition Match',
        status='PASS' if cond_match else 'PARTIAL',
        detail=f"Patient: {patient.get('conditions')} — Trial: {trial.get('conditions')}"
    ))

    return checks, eligible


@app.get("/")
def root():
    return {
        "service":  "Clinical Trial Match Engine",
        "version":  metadata["version"],
        "trials":   metadata["n_trials"],
        "model":    metadata["embedding_model"]
    }


@app.post("/match", response_model=MatchResponse)
def match_patient(patient: PatientProfile):
    try:
        patient_dict = patient.model_dump()
        top_k        = patient_dict.pop("top_k", 5)

        # Embed patient
        patient_text  = build_patient_text(patient_dict)
        patient_embed = embedder.encode(
            [patient_text],
            convert_to_numpy=True,
            normalize_embeddings=True
        ).astype(np.float32)

        # Search FAISS
        scores, indices = index.search(patient_embed, k=len(trials_df))

        matches = []
        for semantic_score, trial_idx in zip(scores[0], indices[0]):
            trial  = trials_df.iloc[trial_idx].to_dict()
            checks, hard_eligible = check_hard_eligibility(patient_dict, trial)

            fail_count = sum(1 for c in checks if c.status == 'FAIL')
            warn_count = sum(1 for c in checks if c.status == 'WARN')

            eligibility_score = float(semantic_score) * 100
            eligibility_score -= fail_count * 25
            eligibility_score -= warn_count * 10
            eligibility_score  = max(0, min(100, eligibility_score))

            matches.append(TrialMatch(
                trial_id=trial['trial_id'],
                title=trial['title'],
                condition=trial['condition'],
                phase=trial['phase'],
                location=trial['location'],
                sponsor=trial['sponsor'],
                semantic_score=round(float(semantic_score) * 100, 2),
                eligibility_score=round(eligibility_score, 2),
                hard_eligible=hard_eligible,
                fail_count=fail_count,
                warn_count=warn_count,
                eligibility_checks=checks
            ))

        matches.sort(key=lambda x: x.eligibility_score, reverse=True)

        return MatchResponse(
            patient_id=patient.patient_id,
            age=patient.age,
            conditions=patient.conditions,
            total_trials=len(trials_df),
            matches=matches[:top_k]
        )

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/trials")
def list_trials():
    return trials_df[['trial_id','title','condition','phase',
                       'location','status']].to_dict(orient='records')


@app.get("/trials/{trial_id}")
def get_trial(trial_id: str):
    trial = trials_df[trials_df['trial_id'] == trial_id]
    if trial.empty:
        raise HTTPException(status_code=404, detail="Trial not found")
    return trial.iloc[0].to_dict()


@app.get("/model/info")
def model_info():
    return metadata