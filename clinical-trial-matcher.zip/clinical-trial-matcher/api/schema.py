from pydantic import BaseModel, Field
from typing import Optional, List

class PatientProfile(BaseModel):
    patient_id:          str   = Field(..., description="Unique patient identifier")
    age:                 int   = Field(..., ge=1, le=120)
    gender:              str   = Field(..., description="Male | Female")
    conditions:          List[str] = Field(..., description="List of diagnosed conditions")
    current_medications: List[str] = Field(default=[], description="Current medications")
    ecog_status:         int   = Field(..., ge=0, le=4, description="ECOG performance status 0-4")
    egfr_value:          float = Field(..., gt=0, description="eGFR mL/min")
    bmi:                 float = Field(..., gt=0, description="Body mass index")
    prior_therapies:     int   = Field(0, ge=0)
    is_pregnant:         bool  = Field(False)
    egfr_mutation:       bool  = Field(False)
    brca_mutation:       bool  = Field(False)
    pdl1_positive:       bool  = Field(False)
    amyloid_positive:    bool  = Field(False)
    hba1c:               Optional[float] = None
    mmse_score:          Optional[int]   = None
    top_k:               int   = Field(5, ge=1, le=12)

class EligibilityCheck(BaseModel):
    criterion: str
    status:    str
    detail:    str

class TrialMatch(BaseModel):
    trial_id:            str
    title:               str
    condition:           str
    phase:               str
    location:            str
    sponsor:             str
    semantic_score:      float
    eligibility_score:   float
    hard_eligible:       bool
    fail_count:          int
    warn_count:          int
    eligibility_checks:  List[EligibilityCheck]

class MatchResponse(BaseModel):
    patient_id:    str
    age:           int
    conditions:    List[str]
    total_trials:  int
    matches:       List[TrialMatch]